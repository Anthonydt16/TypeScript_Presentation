<?php
namespace Library;



/**
 * Librairie Boxcode.
 * 
 * @author chris
 * @version 1.0
 * @package Library
 * @category Librairy
 */
class Boxcode {

    /**
     * Point d'entrée de la librairie.
     * 
     * @access public
     * @return void
     */
    function __construct() {

    }
    
}

?>